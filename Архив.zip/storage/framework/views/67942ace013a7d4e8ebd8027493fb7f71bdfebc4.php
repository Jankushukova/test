<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.brand.insert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4"><div class="chartjs-size-monitor" style="position: absolute; inset: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;"><div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;"><div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div></div><div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;"><div style="position:absolute;width:200%;height:200%;left:0; top:0"></div></div></div>

        <div class="row justify-content-end">
            <div class="col-1">
                <button class="btn btn-info rounded-circle"  data-toggle="modal" data-target="#brandInsertModal">+</button>
            </div>
        </div>
        <h2>Brands</h2>
        <div class="table-responsive">
            <table class="table table-striped table-sm">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Create Date</th>
                    <th>Action</th>
                </tr>
                </thead>
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($brand->id); ?></td>
                    <td><?php echo e($brand->brand); ?></td>
                    <td><?php echo e($brand->created_at); ?></td>
                    <td>
                        <a class="btn btn-warning" href="<?php echo e(route('admin.updateBrand',['id'=>$brand->id])); ?>"> Update</a>
                        <form action="<?php echo e(route('admin.brand', ['id'=>$brand->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button class="btn btn-danger" type="submit"> Delete</button>

                        </form>


                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </main>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/archet/Desktop/LessonTenIntShop/resources/views/admin/brand/index.blade.php ENDPATH**/ ?>